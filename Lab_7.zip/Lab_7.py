from apyori import apriori
import pandas as pd
import numpy as np
data=pd.read_csv("D:\Documents\AA 6th Semester\Labs/store_data.csv",header=None)
data.head()
print(data)
print("After implementing head functon:")
print(data.head())
print("After applying numpy on dataset:")
data_to_numpy=np.array((data))
print(data_to_numpy)
print("After converting dataset to List and calculating association:")

records=[]
for i in range(0,7501):
    records.append([str(data.values[i,j]) for j in range(0,20)])

algo=apriori(records,min_support = 0.0045, min_confidence = 0.2, min_lift = 3,min_length=2)
algo=list(algo)

print(len(algo))
print(algo)
for item in algo:
    pair=item[0]
    items=[x for x in pair]
    print("Rule::" + items[0] + "........." + items[1])
    print("Support:" + str(item[1]))
    print("Confidence:" + str(item[2][0][2]))
    print("Lift:" + str(item[2][0][3]))


