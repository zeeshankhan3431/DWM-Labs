# Q 1
#a
#write your name and display it using with print and then without typing print

z="Zeeshan"
z
print(z)
#b)	Try adding the string to itself using my_string + my_string, or multiplying it by a number,
# e.g., my_string * 3. Notice that the strings are joined together without any spaces. How could you fix this?
a=z*3
print("Print addition of two strings is:",a)
print("print addition of two strings with spaces is:",z + " "  +z +" "+z)

# Q 2
# )Q2: Define list1 to be the list of words ['she', 'sells', 'sea', 'shells', 'by', 'the', 'sea', 'shore'].
# Now write code to perform the following tasks:
#a.	Print all words beginning with sh
#b.	Print all words longer than three characters

l=['she', 'sells', 'sea', 'shells', 'by', 'the', 'sea', 'shore']
print("Words starting with Sh are:")
for i in l:
    if i.startswith("sh"):
        print(i)
print("words greater than 3 charcters are:")
for i in l:
    if len(i)>3:
        print(i)
#Q3: Given two strings, s1, and s2 return a new string made
# of the first, middle, and last characters each input string.
s1="America"
s2="Japan"

def fun(str1, str2):
    l1 = int(len(str1) / 2)
    l2 = int(len(str2) / 2)

    S = str1[0] + str2[0] + str1[l1] + str2[l2] + str1[-1] + str2[-1]
    return S
print("By adjusting the two stringd:")
print(fun('America', 'Japan'))


#Q4)Given 2 strings, s1 and s2, create a new string by appending s2 in the middle of s1

#Given: s1 = "Ault", s2 = "Kelly"
#AuKellylt
str1 = 'Ault'
str2 = 'Kelly'
l = len(str1)//2
str3 = str1[0:l] + str2 + str1[l::]
print("After Appending two strings:\n",str3)

#Q5: Given a two Python list. Iterate both lists simultaneously such that list1 should display
# item in original order and list2 in reverse order.
list1 = [10, 20, 30, 40]
list2 = [100, 200, 300, 400]
print(list1)
list2.reverse()
print(list2)

