#Q1: Write a program that takes two integers as input (lower limit and upper limit)
# and displays all the prime numbers including and between these two numbers.
a=int(input("Enter lower range:"))
b=int(input("Enter upper range:"))
print("Prime Numbers are:")
for number in range(a,b):
    if number>1:
        for i in range(2,number):
            if number%i==0:
                break
        else:
         print(number)


#Q2: Given a list iterate it and display numbers which are divisible by 5 and
# if you find number greater than 150 stop the loop iteration

list1 = [12, 15, 32, 42, 55, 75, 122, 132, 150, 180, 200]
print("Numbers that are divisibleby 5 are:")
for i in list1:
    if i%5==0 and i<150 :
        print(i)

#Q3: Write a program that accepts a comma separated sequence of words as input and
# prints the words in a comma-separated sequence after sorting them alphabetically.
str={
    "what","is","your","favrt","lungs","language"
}
print(sorted(str))

#Q 4
#simple calculator
Print("Simple calculator using Python")
num1=int(input("Enter the first number: "))
num2=int(input("Enter the second number: "))
print("Enter the operator you want to perform");
ch=input("Enter any of these operator for operation +, -, *, /  ")
result=0
if ch=='+':
    result=num1+num2;
elif ch=='-':
    result=num1-num2;
elif ch=='*':
    result=num1*num2;
elif ch=='/':
    result=num1/num2;
else:
   print("char is not supported");
print(num1,ch,num2,": ",result)