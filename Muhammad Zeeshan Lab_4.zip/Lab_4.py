import pandas as pd
data=pd.read_csv("D:\Documents\AA 6th Semester\Labs/rawdata.csv")
print("Original Dataset=")
print(data)
print("After removing missing values with dropna:New data set is:")
print(data.dropna())
print("Filling missing values of dataset by taking median:")
df=data.fillna(data.median())
print(df)
df=df.dropna()
print("Removing the rows which have wrong date format:")
df=df.drop(26)
print(df)
#Now removing the wrong values in data set
print("After removing wrong values in data:")
for x in df.index:
  if df.loc[x, "Duration"] > 120:
    df=df.drop(x)
    print(df)
#Removing the duplicate rows
print("After removing duplicates:")
print(df.drop_duplicates())




